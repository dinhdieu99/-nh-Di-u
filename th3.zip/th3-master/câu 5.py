a=" hello gay"
def say():
    global a
    a=" vinh university"
    print(a)
say()
print(a)
