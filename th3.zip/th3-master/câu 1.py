def sum(a,b):
    print("sum="+str(a+b))
#tính tổng 2 số 4,5
sum(4,5)
#tính tổng 2 số 3,7
sum(3,7)