import math
r=float(input(" nhập vào bán ính hình tròn-->"))
chuvi = 2*math.pi*r
dientich = math.pi*r*r
print(" chu vi hình tron có bán kinh {0} là-->{1}". format(r,chuvi))
print(" diện tích hình tron co bán kinh{0} là-->{1}".format(r,dientich))