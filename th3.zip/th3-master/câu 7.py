def checkValue(n):
    if n%2==0:
        print("đây là một số chẵn")
    else:
        print(" đây là một số lẻ")
checkValue (7)
