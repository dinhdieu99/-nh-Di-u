def say_hello():
    a="chào"
    print(a)
    prin(a)
