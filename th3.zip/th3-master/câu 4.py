a="hello gay!"
def say(a):
    a= " vinh university"
    print(a)
say(a)
print(a)
